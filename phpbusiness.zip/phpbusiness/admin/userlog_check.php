<?php require_once('inc/db.php'); ?>

<?php 
session_start();


if (isset($_POST['login'])) {
	$username = $_POST['username'];
	$passw = $_POST['passw'];

	$sql = "INSERT INTO admin(username,password) VALUES('$username', '$passw')";
	$query = mysqli_query($con,$sql);
	header("Location: home.php");
}


 ?>