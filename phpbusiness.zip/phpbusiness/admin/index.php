<?php require_once('inc/db.php'); ?>
<?php require_once('inc/header.php'); ?>

<div class="loader"></div>
    <!-- header start -->
    <section class="login-content">
        <div class="login-box">
            <form class="login-form" action="userlog_check.php" method="POST">
                <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>SIGN IN</h3>
                <div class="mb-3">
                    <label class="control-label" for="username">USERNAME</label>
                    <input class="form-control" id="username" type="text" name="username" placeholder="User Name" autofocus>
                </div>
                <div class="mb-3">
                    <label class="control-label" for="password">PASSWORD</label>
                    <input class="form-control" id="password" type="password" name="passw" placeholder="Password">
                </div>
              
                <div class="form-group btn-container">
                    <button class="btn btn-primary btn-block w-100" name="login"><i class="fa fa-sign-in fa-lg fa-fw"></i>SIGN IN</button>
                </div>
            </form>
           
        </div>
    </section>

<?php require_once('inc/footer.php'); ?>
