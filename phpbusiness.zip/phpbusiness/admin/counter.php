<?php 
require_once('inc/header.php'); 
require_once('inc/db.php'); 

?>

<body class="sidebar-mini">
    <div class="loader"></div>
    <!-- header start -->
    <header class="adminpopular-header">
        <div class="adminpopular-header-wrapper">
            <!--sidebar menu toggler start -->
            <div class="adminpopular-toggle-sidebar cp-wave-effect">
                <i class="ti-menu adminpopular-close-icon"></i>
            </div>
            <!--sidebar menu toggler end -->

            <div class="adminpopular-header-right adminpopular-with-seperator">
                <!-- header right menu start -->
                <ul class="adminpopular-header-navigation">
                    <li>
                        <a href="#" class="adminpopular-material-button adminpopular-search-toggle"><i
                                class="fa fa-search"></i></a>
                    </li>
                    <li>
                        <a href="#" class="adminpopular-material-button adminpopular-submenu-toggle">
                            <i class="fa fa-comments"></i>
                            <span class="button__badge">82</span>
                        </a>
                        <div class="adminpopular-header-submenu noti-menu">
                            <div class="adminpopular-notify-header">
                                <span class="adminpopular-notify-text-top">9 New</span>
                                <span class="adminpopular-notify-text">User Notifications</span>
                            </div>
                            <div class="noti-box-list">
                                <ul>
                                    <li>
                                        <span class="notification-icon dashbg-gray">
                                            <i class="fa fa-check"></i>
                                        </span>
                                        <span class="notification-text"> <span>Sneha Jogi</span> sent you a message.
                                        </span>
                                        <span class="notification-time">
                                            <a href="#" class="fa fa-close"></a>
                                            <span> 02:14</span>
                                        </span>
                                    </li>
                                    <li>
                                        <span class="notification-icon dashbg-yellow">
                                            <i class="fa fa-shopping-cart"></i>
                                        </span>
                                        <span class="notification-text"> <a href="#">Your order is placed</a> sent you a
                                            message. </span>
                                        <span class="notification-time">
                                            <a href="#" class="fa fa-close"></a>
                                            <span> 7 Min</span>
                                        </span>
                                    </li>
                                    <li>
                                        <span class="notification-icon dashbg-red">
                                            <i class="fa fa-bullhorn"></i>
                                        </span>
                                        <span class="notification-text"> <span>Your item is shipped</span> sent you a
                                            message. </span>
                                        <span class="notification-time">
                                            <a href="#" class="fa fa-close"></a>
                                            <span> 2 May</span>
                                        </span>
                                    </li>
                                    <li>
                                        <span class="notification-icon dashbg-green">
                                            <i class="fa fa-comments-o"></i>
                                        </span>
                                        <span class="notification-text"> <a href="#">Sneha Jogi</a> sent you a message.
                                        </span>
                                        <span class="notification-time">
                                            <a href="#" class="fa fa-close"></a>
                                            <span> 14 July</span>
                                        </span>
                                    </li>
                                    <li>
                                        <span class="notification-icon dashbg-primary">
                                            <i class="fa fa-file-word-o"></i>
                                        </span>
                                        <span class="notification-text"> <span>Sneha Jogi</span> sent you a message.
                                        </span>
                                        <span class="notification-time">
                                            <a href="#" class="fa fa-close"></a>
                                            <span> 15 Min</span>
                                        </span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li>
                        <a href="#" class="adminpopular-material-button adminpopular-submenu-toggle">
                            <i class="fa fa-bell"></i>
                            <span class="button__badge">2</span>
                        </a>
                        <div class="adminpopular-header-submenu noti-menu">
                            <div class="adminpopular-notify-header">
                                <span class="adminpopular-notify-text-top">9 New</span>
                                <span class="adminpopular-notify-text">User Notifications</span>
                            </div>
                            <div class="noti-box-list">
                                <ul>
                                    <li>
                                        <span class="notification-icon dashbg-gray">
                                            <i class="fa fa-check"></i>
                                        </span>
                                        <span class="notification-text"> <span>Sneha Jogi</span> sent you a message.
                                        </span>
                                        <span class="notification-time">
                                            <a href="#" class="fa fa-close"></a>
                                            <span> 02:14</span>
                                        </span>
                                    </li>
                                    <li>
                                        <span class="notification-icon dashbg-yellow">
                                            <i class="fa fa-shopping-cart"></i>
                                        </span>
                                        <span class="notification-text"> <a href="#">Your order is placed</a> sent you a
                                            message. </span>
                                        <span class="notification-time">
                                            <a href="#" class="fa fa-close"></a>
                                            <span> 7 Min</span>
                                        </span>
                                    </li>
                                    <li>
                                        <span class="notification-icon dashbg-red">
                                            <i class="fa fa-bullhorn"></i>
                                        </span>
                                        <span class="notification-text"> <span>Your item is shipped</span> sent you a
                                            message. </span>
                                        <span class="notification-time">
                                            <a href="#" class="fa fa-close"></a>
                                            <span> 2 May</span>
                                        </span>
                                    </li>
                                    <li>
                                        <span class="notification-icon dashbg-green">
                                            <i class="fa fa-comments-o"></i>
                                        </span>
                                        <span class="notification-text"> <a href="#">Sneha Jogi</a> sent you a message.
                                        </span>
                                        <span class="notification-time">
                                            <a href="#" class="fa fa-close"></a>
                                            <span> 14 July</span>
                                        </span>
                                    </li>
                                    <li>
                                        <span class="notification-icon dashbg-primary">
                                            <i class="fa fa-file-word-o"></i>
                                        </span>
                                        <span class="notification-text"> <span>Sneha Jogi</span> sent you a message.
                                        </span>
                                        <span class="notification-time">
                                            <a href="#" class="fa fa-close"></a>
                                            <span> 15 Min</span>
                                        </span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li>
                        <a href="#" class="adminpopular-material-button adminpopular-submenu-toggle">
                            <span class="adminpopular-user-avatar"><img alt="" src="assets/images/pic.jpg" width="32"
                                    height="32" /></span>
                        </a>
                        <div class="adminpopular-header-submenu">
                            <ul>
                                <li><a href="page-user.html">My profile</a></li>
                                <li><a href="mailbox.html">Activity</a></li>
                                <li><a href="chat.html">Messages</a></li>
                                <li>
                                    <a href="page-login.html">Logout <i class="fa fa-sign-out"></i></a>
                                </li>
                            </ul>
                        </div>
                    </li>
                </ul>
                <!-- header right menu end -->
            </div>
            <!--header search panel start -->
            <div class="adminpopular-search-bar">
                <form class="adminpopular-search-form">
                    <div class="adminpopular-search-input-wrapper">
                        <input type="text" name="qq" placeholder="search something..."
                            class="adminpopular-search-input" />
                        <button type="submit" name="search" class="adminpopular-search-submit"><i
                                class="ti-arrow-right"></i></button>
                    </div>
                    <span class="adminpopular-search-close adminpopular-search-toggle">
                        <i class="ti-close"></i>
                    </span>
                </form>
            </div>
            <!--header search panel end -->
        </div>
    </header>
    <!-- header end -->
    <!-- Left sidebar menu start -->
    <aside class="adminpopular-sidebar">

        <!--logo start -->
        <div class="adminpopular-logo-box">
            <div>
                <a href="home.php" class="adminpopular-logo"><i class="fa fa-home"></i> AdminPopular</a>
            </div>
        </div>
        <!--logo end -->
        <div class="sidebar-user">
            <img class="sidebar-user-avatar" src="assets/images/pic.jpg" alt="User Image">
            <div>
                <p class="sidebar-user-name">John Doe</p>
                <p class="sidebar-user-designation">Frontend Developer</p>
            </div>
        </div>
        <ul class="adminpopular-menu">

            <li class="treeview">
                <a class="nav-item" href="#" data-toggle="treeview">
                    <i class="nav-icon fa fa-home"></i>
                    <span class="nav-label">Dashboard</span>
                    <i class="treeview-icon fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="index-2.html">Default</a></li>
                    <li><a class="treeview-item" href="index-light.html">Dashboard Light</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a class="nav-item" href="#" data-toggle="treeview">
                    <i class="nav-icon fa fa-bullhorn"></i>
                    <span class="nav-label">UI Elements</span>
                    <i class="treeview-icon fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="button.html">Button</a></li>
                    <li><a class="treeview-item" href="widget.html">Widget</a></li>
                    <li><a class="treeview-item" href="tab-and-accordian.html">Tab and Accordion</a></li>
                    <li><a class="treeview-item" href="progress-bar.html">Progress Bar</a></li>
                    <li><a class="treeview-item" href="alert.html">Alert</a></li>
                    <li><a class="treeview-item" href="modal.html">Popup Modal</a></li>
                    <li><a class="treeview-item" href="typography.html">Typography</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a class="nav-item" href="#" data-toggle="treeview">
                    <i class="nav-icon fa fa-shopping-cart"></i>
                    <span class="nav-label">eCommerce</span>
                    <i class="treeview-icon fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="product-list.html">Product List</a></li>
                    <li><a class="treeview-item" href="order-list.html">Order List</a></li>
                    <li><a class="treeview-item" href="order-view.html">Order View</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a class="nav-item" href="#" data-toggle="treeview">
                    <i class="nav-icon fa fa-envelope"></i>
                    <span class="nav-label">Mailbox</span>
                    <i class="treeview-icon fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="mailbox.html">Inbox</a></li>
                    <li><a class="treeview-item" href="mailbox-compose.html">Compose</a></li>
                    <li><a class="treeview-item" href="mailbox-read.html">Read</a></li>
                </ul>
            </li>

            <li>
                <a class="nav-item" href="page-calendar.html">
                    <i class="nav-icon fa fa-calendar"></i>
                    <span class="nav-label">Calendar</span>
                </a>
            </li>

            <li class="treeview">
                <a class="nav-item" href="#" data-toggle="treeview">
                    <i class="nav-icon fa fa-list"></i>
                    <span class="nav-label">Table</span>
                    <i class="treeview-icon fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="table-simple.html">Basic Table</a></li>
                    <li><a class="treeview-item" href="table-data.html">Data Table</a></li>
                </ul>
            </li>

            <li>
                <a class="nav-item" href="chart.html">
                    <i class="nav-icon fa fa-pie-chart"></i>
                    <span class="nav-label">Charts</span>
                </a>
            </li>

            <li class="treeview">
                <a class="nav-item" href="#" data-toggle="treeview">
                    <i class="nav-icon fa fa-list"></i>
                    <span class="nav-label">Icons</span>
                    <i class="treeview-icon fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="fontawesome.html">Font Awesome Icons</a></li>
                    <li><a class="treeview-item" href="icon-themify.html">Themify Icons</a></li>
                    <li><a class="treeview-item" href="icon-simple-line.html">Simple Line Icons</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a class="nav-item" href="#" data-toggle="treeview">
                    <i class="nav-icon fa fa-edit"></i>
                    <span class="nav-label">Forms</span>
                    <i class="treeview-icon fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="form-element.html">Form Elements</a></li>
                    <li><a class="treeview-item" href="form-validation.html">Validation Form</a></li>
                    <li><a class="treeview-item" href="form-wizard.html">Wizard Form</a></li>
                    <li><a class="treeview-item" href="form-text-editor.html">Form Text Editor</a></li>
                </ul>
            </li>

            <li class="treeview is-expanded">
                <a class="nav-item active" href="#" data-toggle="treeview">
                    <i class="nav-icon fa fa-bookmark"></i>
                    <span class="nav-label">Home Page</span>
                    <i class="treeview-icon fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                   <li><a class="treeview-item" href="service.php">Service</a></li>
                    <li><a class="treeview-item" href="our_team.php">Our Team</a></li>
                    <li><a class="treeview-item" href="counter.php">Counter</a></li>
                </ul>
            </li>

            <li>
                <a class="nav-item" href="chat.html">
                    <i class="nav-icon fa fa-comments"></i>
                    <span class="nav-label">Chat</span>
                </a>
            </li>

            <li class="treeview">
                <a class="nav-item" href="#" data-toggle="treeview">
                    <i class="nav-icon fa fa-map-marker"></i>
                    <span class="nav-label">Map</span>
                    <i class="treeview-icon fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="gmap.html">Google Map</a></li>
                    <li><a class="treeview-item" href="vmap.html">Vector Map</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a class="nav-item" href="#" data-toggle="treeview">
                    <i class="nav-icon fa fa-user"></i>
                    <span class="nav-label">My Profile</span>
                    <i class="treeview-icon fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="page-user.html">User Profile</a></li>
                    <li><a class="treeview-item" href="page-login.html">Login</a></li>
                    <li><a class="treeview-item" href="page-register.html">Register</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a class="nav-item" href="#" data-toggle="treeview">
                    <i class="nav-icon fa fa-sitemap"></i>
                    <span class="nav-label">Multiple Menu</span>
                    <i class="treeview-icon fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="#">Menu Lavel One</a></li>
                    <li><a class="treeview-item" href="#">Menu Lavel One</a></li>
                    <li class="treeview-inner"><a class="treeview-item" href="#" data-toggle="treeview-inner">Menu Lavel
                            One <i class="treeview-inner-icon fa fa-angle-right"></i> </a>
                        <ul class="treeview-inner-menu">
                            <li><a class="treeview-item" href="#">Menu Lavel Two</a></li>
                            <li><a class="treeview-item" href="#">Menu Lavel Two</a></li>
                            <li><a class="treeview-item" href="#">Menu Lavel Two</a></li>
                            <li><a class="treeview-item" href="#">Menu Lavel Two</a></li>
                            <li><a class="treeview-item" href="#">Menu Lavel Two</a></li>
                        </ul>
                    </li>
                    <li><a class="treeview-item" href="#">Menu Lavel One</a></li>
                </ul>
            </li>

        </ul>
    </aside>
    <!-- Left sidebar menu end -->
    <!--Main container start -->








    <main class="adminpopular-wrapper">
        <div class="container-fluid">
            <!-- breadcum -->
            <div class="db-breadcrumb">
                <h4 class="breadcrumb-title">Dashboard</h4>
                <ul class="db-breadcrumb-list">
                    <li><a href="index-2.html"><i class="fa fa-home"></i>Home</a></li>
                    <li>Basic Table</li>
                </ul>
            </div>
            <!-- End breadcum -->
            <div class="row">


                <section class="ap-sec-wrapper title">
                    <h5 class="title-text">Add Your Counter information</h5>
                    <div class="row">
                        <div class="col-sm">
                            <form class="mb-30" action="admin_function.php" method="POST">
                                <div class="form-group">
                                    <label>Counter Title</label>
                                    <input type="text" class="form-control"
                                    aria-describedby="passwordHelpBlock" name="counter_title">
                                </div>

                                <div class="form-group">
                                    <label>Counter Amount</label>
                                    <input type="text" class="form-control"
                                    aria-describedby="passwordHelpInline" name="counter_amt">
                                </div> 
                                <br>
                                <button class="btn btn-primary" type="submit" name="counbtn">Add New Counter</button>
                            </form>

                        </div>
                    </div>
                </section> 


                <section class="ap-sec-wrapper title">
                    <h5 class="title-text">Add Your Counter information</h5>
                    <div class="row">
                        <div class="col-sm">
                            <form class="mb-30" action="" method="POST">
                                <?php 
                                if (isset($_GET['update'])) {
                                    $counid = $_GET['update'];
                                   $sql = "SELECT * FROM counter WHERE id={$counid}";
                                   $query = mysqli_query($con,$sql);
                                   while ($dashow = mysqli_fetch_assoc($query)) {
                                       $counterid = $dashow['id'];
                                       $counter_title = $dashow['counter_title'];
                                       $counter_amt = $dashow['counter_amt'];
                                 ?>
                                <div class="form-group">
                                    <label>Counter Title</label>
                                    <input type="text" class="form-control"
                                    aria-describedby="passwordHelpBlock" name="counter_title" value="<?php echo $counter_title ; ?>">
                                </div>

                                <div class="form-group">
                                    <label>Counter Amount</label>
                                    <input type="text" class="form-control"
                                    aria-describedby="passwordHelpInline" name="counter_amt" value="<?php echo $counter_amt; ?>">
                                </div> 
                                <br>
                                <button class="btn btn-primary" type="submit" name="updatebtn">Update Counter</button>
                            <?php } } ?>


                            <?php 
                            if (isset($_POST['updatebtn'])) {
                                $counter_title = $_POST['counter_title'];
                                $counter_amt = $_POST['counter_amt'];
                                $sql = "UPDATE counter SET counter_title='$counter_title', counter_amt='$counter_amt' WHERE id=$counid";
                                $query = mysqli_query($con,$sql);
                            }
                             ?>

                            </form>

                        </div>
                    </div>
                </section>  

              


                <div class="clearfix"></div>
                <div class="col-md-12">
                    <div class="title">
                        <h3 class="title-text">Counter Information</h3>
                        <div class="table-responsive">
                            <table class="table f-border-none">
                                <thead>
                                    <tr>
                                        <th>SI No</th>
                                        <th>Counter Title</th>
                                        <th>Counter Amount</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <?php 
                                $sql = "SELECT * FROM counter";
                                $query = mysqli_query($con,$sql);
                                if ($query->num_rows >0) {
                                    while ($dshow = mysqli_fetch_assoc($query)) {
                                      $counid = $dshow['id'];
                                      $counter_title = $dshow['counter_title'];
                                      $counter_amt = $dshow['counter_amt'];

                                      ?>
                                      <tbody>
                                        <tr>
                                            <td><?php echo $counid; ?></td>
                                            <td><?php echo $counter_title; ?></td>
                                            <td><?php echo $counter_amt; ?></td>
                                            <td><a class="btn btn-primary" href="counter.php?update=<?php echo $counid; ?>">Update</a></td>
                                            <td><a class="btn btn-danger" href="admin_function.php?delete=<?php echo $counid; ?>">Delete</a></td>
                                        </tr>                         
                                    </tbody>
                                <?php } } ?>

                            </table>
                        </div>
                    </div>




            </div>
        </div>
        <!-- End container -->
    </main>










<?php require_once('inc/footer.php'); ?>
