<?php require_once('inc/db.php'); ?>
<?php 

// This section for service section option

if (isset($_POST['serbtn'])) {
	$ser_title = $_POST['ser_title'];
	$ser_desc = $_POST['ser_desc'];
	$ser_icon = $_POST['ser_icon'];
	$sql = "INSERT INTO service(service_title,service_desc) VALUES('$ser_title','$ser_desc')";
	$query = mysqli_query($con,$sql);
	header('Location: service.php');
}



// this section for our team section

if (isset($_POST['teambtn'])) {
	$team_name = $_POST['team_name'];
	$team_desig = $_POST['team_desig'];
	$team_img = $_POST['team_img'];


	$team_img = $_FILES["team_img"]["name"];
	$team_img_gg = $_FILES["team_img"]["tmp_name"];

	move_uploaded_file($team_img_gg, "uploadimg/$team_img");


	$sql = "INSERT INTO outteam(team_name,team_desig,team_image) VALUES('$team_name','$team_desig','$team_img')";
	$query = mysqli_query($con,$sql);
	header('Location: our_team.php');
}



// this section for home page counter

if (isset($_POST['counbtn'])) {
	$cou_title = $_POST['counter_title'];
	$cou_amt = $_POST['counter_amt'];
	$sql = "INSERT INTO counter(counter_title,counter_amt) VALUES('$cou_title','$cou_amt')";
	$query = mysqli_query($con,$sql);
	header('Location: counter.php');
}


 // start home page counter delete function
if (isset($_GET['delete'])) {
    $deleteid = $_GET['delete'];
    $sql = "DELETE FROM counter WHERE id ={$deleteid}";
    $query = mysqli_query($con,$sql);
    header('Location: counter.php');
}
  

// start home page about us section data insert function

if (isset($_POST['aboutbtn'])) {
    $about_title = $_POST['about_title'];
    $about_desc = $_POST['about_desc'];
    $about_ima = $_POST['about_img'];


	$about_ima = $_FILES["about_ima"]["name"];
	$about_img_gg = $_FILES["about_ima"]["tmp_name"];

	move_uploaded_file($about_img_gg, "uploadimg/$about_ima");

   $sql = "INSERT INTO aboutus(aboutus_title,aboutus_desc,aboutus_img) VALUES('$about_title','$about_desc','$about_ima')";
   $query = mysqli_query($con,$sql);
   header('Location: aboutus.php');
}               


// start home page about section delete function

if (isset($_GET['delete'])) {
	$delete_id = $_GET['delete'];
	$sql = "DELETE FROM aboutus WHERE id={$delete_id}";
	$query = mysqli_query($con,$sql);
	header('Location: aboutus.php');
}


 

                             







  