<!DOCTYPE html>
<html lang="en">
<head>
	<title>Business: Business Multipurpose HTML template</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Business: Business Multipurpose HTML template">
    <meta name="keywords" content="bootweb, multipurpose, portfolio, personal, developer, designer, onepage, clean, minimal, modern">
    <meta name="author" content="Tanmoy Dhar">
	
	  <!-- All CSS Files -->
    <link rel="shortcut icon" href="#" type="image/png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link href="css/slick.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/slicknav.min.css">
    <link href="css/slick-theme.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/icofont.css">
    <link rel="stylesheet" type="text/css" href="css/jquery.lineProgressbar.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link id="colors" rel="stylesheet" href="css/colors/defaults-color.css">

</head>