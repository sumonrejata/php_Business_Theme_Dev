
    <!-- All JS Here -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.parallax-1.1.3.js"></script>
    <script src="js/slick.min.js"></script>  
    <script src="js/jquery.magnific-popup.min.js"></script> 
    <script src="js/wow.min.js"></script> 
    <script src="js/isotope.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.lineProgressbar.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script src="js/tweetie.js"></script>
    <script src="js/main.js"></script>
</body>
</html>